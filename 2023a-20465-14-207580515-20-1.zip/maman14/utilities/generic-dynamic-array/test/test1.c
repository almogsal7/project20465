#include "../inc/gda.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void * string_ctor(const void *candidate) {
    void *ret;
    size_t str_len = strlen((const char *)candidate);
    ret = calloc(str_len + 1,sizeof(char));
    if(!ret)
        return NULL;
    return strcpy((char*)ret,(const char *)candidate);
}


void string_dtor(void * candidate) {
    free(candidate);
}

int main() {
    int i=0;
    char *find;
    void *const* begin;
    void *const *end;
    const char *strings[3] = {"yotam","ronen","shira"};
    const char *strings2[4] = {"yotam","yoram","ronen","shira"};
    
    gda g_strings = gda_create(string_ctor,string_dtor,( int (*)(const void *,const void *))strcmp);
    
    for(i=0;i<3;i++) {
        gda_insert(g_strings,strings[i]);
    }
    
    for(i=0;i<4;i++) {
        find = gda_search(g_strings,strings2[i]);
        printf("found:%s\n",find);
    }
    
    gda_for_each(g_strings,begin,end) {
        if(*begin != NULL) {
            printf("%s\n",(char*)*begin);
        }
    }
    gda_destroy(g_strings);
    return 0;
}