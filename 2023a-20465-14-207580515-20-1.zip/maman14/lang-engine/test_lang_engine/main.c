
#include "../inc/lang-engine.h"



#define test_size 37
int main() {
    struct syntax_struct s_struct;
    int i;
    char tests[test_size][200] = {
        "bne r3",
        "not Label1",
        "clr    r2",
        "   bne LOOP(r3,    r4)",
        "  jmp   l1(#-1,r6)",
        "bne   loop(K,STR)",
        "F: mov   #4,   #2",
        "MAIN:   mov r3,r4",
        "FOO:   add r3,LOL",
        "MAIN:  mov         r7          ,  r2",
        "MAIN: mov          r2,    #10213423984023948239048239402384",
        "main:    mov   r2    r5",
        "lea     LAB1,   LAB2    ",
        ".data 1,2,3",
        ".data     1   ,  2   , 3",
        ".data  1,2   3",
        ".data  123ge,12",
        ".data    ",
        ".string   ",
        ".string            \"stam mahrozet123\"",
        ".string      \"foo123",
        ".string        foo123\"",
        ".string      \"yolo\"   003",
        ".entry           ",
        ".extern           ",
        ".extern foo   foo",
        ".entry foo   foo",
        ".entry foo",
        ".extern    foo1",
        "MAIN:        mov r3,LENGTH",
        "!MAIN:        mov r3,LENGTH",
        "asdsadasdasdasdsasadasdasdeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeMAIN:        mov r3,LENGTH",
        "MAIN:        mov : r3,LENGTH",
        "MA@IN:        mov  r3,LENGTH",
        "foo:   stop",
        "foo1:   stop arg1",
        "foo2:   .data"
    };
    for(i =0 ;i<test_size;i++) {
        s_struct = lang_engine_create_ss_from_logical_line(tests[i]);
    }
    return 0;
}