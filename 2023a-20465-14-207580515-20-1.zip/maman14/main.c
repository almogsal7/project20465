#include "assembler/inc/assembler.h"




int main(int argc, char **argv ){
    argv++;argc--;
    return assemble(argv,argc);
}