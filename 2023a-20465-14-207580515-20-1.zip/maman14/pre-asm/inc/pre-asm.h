#ifndef maman14_pre_asm_h
#define maman14_pre_asm_h



/**
 * @brief 
 * 
 * @param am_file 
 * @return const char* 
 */
const char * asm_pre_asm(const char *base_name);


#endif